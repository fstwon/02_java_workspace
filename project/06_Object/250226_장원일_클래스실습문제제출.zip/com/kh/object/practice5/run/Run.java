package com.kh.object.practice5.run;
import com.kh.object.practice5.model.vo.Lotto;

public class Run {

	public static void main(String[] args) {
		Lotto lotto = new Lotto();
		lotto.information();
	}
}
