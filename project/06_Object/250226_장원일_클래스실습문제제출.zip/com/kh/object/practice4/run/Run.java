package com.kh.object.practice4.run;
import com.kh.object.practice4.model.vo.Student;

public class Run {

	public static void main(String[] args) {
		/*
		grade : int
		classroom : int
		name : String
		height : double
		gender : char 
		 */	
		Student s = new Student();
		s.information();
	}

}
